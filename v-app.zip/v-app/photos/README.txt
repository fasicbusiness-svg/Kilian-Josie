Lege hier eure Fotos ab (z.B. wir1.jpg, wir2.jpg ...) und trage die Dateinamen oben in index.html in WIR_PHOTOS ein.
